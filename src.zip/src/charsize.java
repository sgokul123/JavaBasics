
public class charsize {
public static void main(String args[]){
	int a,b;
	char c='c';
	a='c';
	b='a';
	System.out.println(a);
	System.out.println(b);
}
}
