

class Qnodes{
	static int data=0;
	static Qnodes next=null;
	Qnodes(int val,Qnodes link){
		data=val;
		next=link;
	}
	
}
public class isNull {
public static void main(){
}
}
