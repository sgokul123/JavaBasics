
public class JsonInventory {

}
